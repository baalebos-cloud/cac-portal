curl --location '/nin/' \
--header 'Authorization: Bearer lv_Aijalon_8svgnj9ztf5c4do1m' \
--header 'Content-Type: application/json' \
--data '{
        "number": "12345678901"
}'
