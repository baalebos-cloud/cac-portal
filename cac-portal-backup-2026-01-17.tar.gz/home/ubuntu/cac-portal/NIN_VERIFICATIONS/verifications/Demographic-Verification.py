curl --location '/demo/' \
--header 'Authorization: Bearer lv_Aijalon_8svgnj9ztf5c4do1m' \
--header 'Content-Type: application/json' \
--data '{
    "firstname": "usman",
    "lastname": "john",
    "gender": "m",
    "dob": "20-11-1000"
}'
