from flask_login import login_user, logout_user
from models.user import User
from extensions import db
