from flask import Blueprint, render_template, request, redirect, url_for, flash
from extensions import db
from models.ngo import NGO
from models.payment import Payment

ngo_bp = Blueprint("ngo", __name__, template_folder="../templates")

@ngo_bp.route("/", methods=["GET", "POST"])
def register_ngo():
    if request.method == "POST":
        try:
            ngo = NGO(
                proposed_name_1=request.form.get("proposed_name_1"),
                proposed_name_2=request.form.get("proposed_name_2"),
                mission=request.form.get("mission"),
                state=request.form.get("state"),
                lga=request.form.get("lga"),
                city=request.form.get("city"),
                street=request.form.get("street"),
                phone=request.form.get("phone"),
                email=request.form.get("email"),
                trustees_count=request.form.get("trustees_count")
            )

            db.session.add(ngo)
            db.session.commit()

            payment = Payment(
                service="NGO Registration",
                amount=ngo.amount,
                status="Pending",
                reference=f"NGO-{ngo.id}"
            )

            db.session.add(payment)
            db.session.commit()

            flash("NGO registration submitted successfully", "success")
            return redirect(url_for("ngo.register_ngo"))

        except Exception as e:
            db.session.rollback()
            flash(f"Error: {str(e)}", "danger")

    return render_template("ngo.html")


