from flask import Blueprint, request, jsonify, redirect, render_template, url_for
from extensions import db
from models.business_name import BusinessName

business_name_bp = Blueprint("business_name", __name__)

@business_name_bp.route('/')
def index():
    return "Business Name Portal"

@business_name_bp.route("/submit", methods=["POST"])
def submit_business_name():
    try:
        data = request.form

        record = BusinessName(
            first_name=data.get("first_name"),
            middle_name=data.get("middle_name"),
            surname=data.get("surname"),
            date_of_birth=data.get("date_of_birth"),
            nationality=data.get("nationality"),
            state_of_origin=data.get("state_of_origin"),
            lga=data.get("lga"),
            email=data.get("email"),
            residential_address=data.get("residential_address"),
            house_number=data.get("house_number"),
            business_address=data.get("business_address"),
            business_description=data.get("business_description"),
            proposed_business_name=data.get("proposed_business_name"),
            nin_number=data.get("nin_number"),
            phone_number=data.get("phone_number"),
        )

        db.session.add(record)
        db.session.commit()

        return jsonify({
            "status": "success",
            "message": "Business Name submitted successfully"
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

